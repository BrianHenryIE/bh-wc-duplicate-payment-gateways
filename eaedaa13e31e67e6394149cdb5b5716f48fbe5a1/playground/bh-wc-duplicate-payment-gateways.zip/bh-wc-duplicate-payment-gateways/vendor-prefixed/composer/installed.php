<?php return array (
  'root' => 
  array (
    'name' => 'brianhenryie/bh-wc-duplicate-payment-gateways',
    'pretty_version' => 'dev-4964b9e592f59864f6ceb921e3af2725ec477c10',
    'version' => 'dev-4964b9e592f59864f6ceb921e3af2725ec477c10',
    'reference' => '4964b9e592f59864f6ceb921e3af2725ec477c10',
    'type' => 'wordpress-plugin',
    'install_path' => __DIR__ . '/../',
    'aliases' => 
    array (
    ),
    'dev' => true,
  ),
  'versions' => 
  array (
    'alleyinteractive/wordpress-autoloader' => 
    array (
      'pretty_version' => 'v1.2.1',
      'version' => '1.2.1.0',
      'reference' => '570a0e911f806448d2709864729a53731c49fcd9',
      'type' => 'library',
      'install_path' => __DIR__ . '/../alleyinteractive/wordpress-autoloader',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
  ),
);