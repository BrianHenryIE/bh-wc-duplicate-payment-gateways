<?php
/**
 * Not an actual gateway, just filters.
 *
 * If a new gateway title or description has been set, display that instead of the parent gateway's description/...
 *
 * @package brianhenryie/bh-wc-duplicate-payment-gateways
 */

declare(strict_types=1);

namespace BrianHenryIE\WC_Duplicate_Payment_Gateways\WooCommerce;

use BrianHenryIE\WC_Duplicate_Payment_Gateways\API\Gateway_Copy_Interface;
use WC_Payment_Gateway;

/**
 * Replace title, replace description.
 */
class Payment_Gateway {

	/**
	 * If a new title has been specified for the gateway, replace the parent title. Otherwise, for duplicates, append
	 * the gateway id to distinguish it from the original.
	 * Applies in the wp-admin area (i.e. this is not the title shown to customer at checkout).
	 *
	 * @hooked woocommerce_gateway_method_title
	 * @see WC_Payment_Gateway::get_method_title()
	 *
	 * @param string             $method_title The original payment method title.
	 * @param WC_Payment_Gateway $gateway      The payment gateway instance.
	 * @return string
	 */
	public function replace_title( string $method_title, WC_Payment_Gateway $gateway ): string {

		$new_title = $gateway->get_option( Payment_Gateway_Settings::ADMIN_METHOD_TITLE );

		if ( ! empty( $new_title ) ) {
			return $new_title;
		}

		// Otherwise the duplicate has the same title as the original in WooCommerce / Settings / Payments.
		if ( $gateway instanceof Gateway_Copy_Interface ) {
			return "{$method_title} ({$gateway->id})";
		}

		return $method_title;
	}

	/**
	 * If a new admin description has been specified for the gateway, replace the parent description.
	 *
	 * @hooked woocommerce_gateway_method_description
	 * @see WC_Payment_Gateway::get_method_description()
	 *
	 * @param string             $method_description The original payment method description.
	 * @param WC_Payment_Gateway $gateway            The payment gateway instance.
	 */
	public function replace_description( string $method_description, WC_Payment_Gateway $gateway ): string {

		$new_description = $gateway->get_option( Payment_Gateway_Settings::ADMIN_DESCRIPTION );

		if ( ! empty( $new_description ) ) {
			return $new_description;
		}

		return $method_description;
	}
}
