<?php return array (
  'root' => 
  array (
    'name' => 'brianhenryie/bh-wc-duplicate-payment-gateways',
    'pretty_version' => 'dev-c97d168e9bcd082333ef58dec7ce1eb90a771273',
    'version' => 'dev-c97d168e9bcd082333ef58dec7ce1eb90a771273',
    'reference' => 'c97d168e9bcd082333ef58dec7ce1eb90a771273',
    'type' => 'wordpress-plugin',
    'install_path' => __DIR__ . '/../',
    'aliases' => 
    array (
    ),
    'dev' => true,
  ),
  'versions' => 
  array (
    'alleyinteractive/wordpress-autoloader' => 
    array (
      'pretty_version' => 'v1.2.1',
      'version' => '1.2.1.0',
      'reference' => '570a0e911f806448d2709864729a53731c49fcd9',
      'type' => 'library',
      'install_path' => __DIR__ . '/../alleyinteractive/wordpress-autoloader',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
  ),
);