<?php return array (
  'root' => 
  array (
    'name' => 'brianhenryie/bh-wc-duplicate-payment-gateways',
    'pretty_version' => 'dev-b13e8782601d150106449229f7e717e3c3bd0196',
    'version' => 'dev-b13e8782601d150106449229f7e717e3c3bd0196',
    'reference' => 'b13e8782601d150106449229f7e717e3c3bd0196',
    'type' => 'wordpress-plugin',
    'install_path' => __DIR__ . '/../',
    'aliases' => 
    array (
    ),
    'dev' => true,
  ),
  'versions' => 
  array (
    'alleyinteractive/wordpress-autoloader' => 
    array (
      'pretty_version' => 'v1.2.1',
      'version' => '1.2.1.0',
      'reference' => '570a0e911f806448d2709864729a53731c49fcd9',
      'type' => 'library',
      'install_path' => __DIR__ . '/../alleyinteractive/wordpress-autoloader',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
  ),
);